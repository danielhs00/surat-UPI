<?php

return [
    'name' => 'Template',
];
