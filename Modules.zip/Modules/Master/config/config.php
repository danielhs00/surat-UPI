<?php

return [
    'name' => 'Master',
];
