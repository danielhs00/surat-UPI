<?php

namespace Modules\Wadek\Database\Seeders;

use Illuminate\Database\Seeder;

class WadekDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
