<?php

return [
    'name' => 'Wadek',
];
