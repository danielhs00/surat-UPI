<!DOCTYPE html>
<html lang="en">
<!-- [Head] start -->

<head>
    <title>Mahasiswa Template</title>
    <!-- [Meta] -->
    <x-mahasiswa::meta></x-mahasiswa::meta>

    <x-mahasiswa::sidebar.links></x-mahasiswa::sidebar.links>

</head>
<!-- [Head] end -->
<!-- [Body] Start -->

<body data-pc-preset="preset-1" data-pc-direction="ltr" data-pc-theme="light">
    <!-- [ Pre-loader ] start -->
    <div class="loader-bg">
        <div class="loader-track">
            <div class="loader-fill"></div>
        </div>
    </div>
    <!-- [ Pre-loader ] End -->
    <!-- [ Sidebar Menu ] start -->
    <x-mahasiswa::sidebar></x-mahasiswa::sidebar>

    <!-- [ Sidebar Menu ] end -->
    <!-- [ Header Topbar ] start -->
    <x-mahasiswa::header></x-mahasiswa::header>
    <!-- [ Header ] end -->



    <!-- [ Main Content ] start -->
    <div class="pc-container">
        <div class="pc-content">
            <!-- [ breadcrumb ] start -->
            <x-mahasiswa::breadcrumbs></x-mahasiswa::breadcrumbs>
            <!-- [ breadcrumb ] end -->
            <!-- [ Main Content ] start -->

            <div class="row">
                @if (session('success'))
                    <div class="">
                        <div class="alert alert-success" id="success-alert" role="alert">
                            {{ session('success') }}
                        </div>
                    </div>
                @endif
                @yield('content')
            </div>


        </div>
    </div>
    <!-- [ Main Content ] end -->
    <x-mahasiswa::footer></x-mahasiswa::footer>

    <!-- [Page Specific JS] start -->
    <script src="{{ asset('dist') }}/assets/js/plugins/apexcharts.min.js"></script>
    <script src="{{ asset('dist') }}/assets/js/pages/dashboard-default.js"></script>
    <!-- [Page Specific JS] end -->
    <!-- Required Js -->
    <script src="{{ asset('dist') }}/assets/js/plugins/popper.min.js"></script>
    <script src="{{ asset('dist') }}/assets/js/plugins/simplebar.min.js"></script>
    <script src="{{ asset('dist') }}/assets/js/plugins/bootstrap.min.js"></script>
    <script src="{{ asset('dist') }}/assets/js/fonts/custom-font.js"></script>
    <script src="{{ asset('dist') }}/assets/js/pcoded.js"></script>
    <script src="{{ asset('dist') }}/assets/js/plugins/feather.min.js"></script>

    <script>
        layout_change('light');
    </script>
    <script>
        change_box_container('false');
    </script>
    <script>
        layout_rtl_change('false');
    </script>
    <script>
        preset_change("preset-1");
    </script>
    <script>
        font_change("Public-Sans");
    </script>
</body>
<!-- [Body] end -->

</html>
