<?php

namespace Modules\Mahasiswa\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Modules\Mahasiswa\Models\Template;
use Modules\Mahasiswa\Models\StudentDocument;

class MahasiswaDashboardController extends Controller
{
    public function index(Request $request)
    {
        $templates = Template::query()
            ->where('is_active', true)
            ->orderBy('name')
            ->get();

        $status = $request->query('status'); // ambil dari ?status=

        $recentDocsQuery = StudentDocument::query()
            ->where('user_id', Auth::id());

        // filter status (kalau dipilih)
        if (!empty($status) && $status !== 'all') {
            $recentDocsQuery->where('status', $status);
        }

        $recentDocs = $recentDocsQuery
            ->orderByDesc('updated_at') // terakhir diubah
            ->limit(12)
            ->get();

        return view('mahasiswa::components.mahasiswa.index', compact('templates', 'recentDocs', 'status'));
    }
}