<x-mahasiswa::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('mahasiswa.name') !!}</p>
</x-mahasiswa::layouts.master>
