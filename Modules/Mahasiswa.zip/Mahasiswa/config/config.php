<?php

return [
    'name' => 'Mahasiswa',
];
