<?php

namespace Modules\Mahasiswa\Database\Seeders;

use Illuminate\Database\Seeder;

class MahasiswaDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
