<?php

return [
    'name' => 'Users',
];
