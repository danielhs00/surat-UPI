<?php

namespace Modules\Auth\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    public function show()
    {
        return view('auth::login');
    }

    public function store(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);

        // Dummy account (sementara)
        if ($request->email === 'admin@upi.test' && $request->password === 'admin123') {
            session([
                'logged_in' => true,
                'role' => 'mahasiswa',   // atau admin, bebas
                'email' => $request->email,
                'user_id' => 1,          // sementara hardcode dulu
            ]);

            // Redirect bebas (sementara)
            return redirect(route('mahasiswa.index'));
        }

        return back()->withErrors(['email' => 'Email atau password salah']);
    }
    public function destroy(Request $request)
    {
        $request->session()->flush();
        return redirect()->route('login');
    }
}
